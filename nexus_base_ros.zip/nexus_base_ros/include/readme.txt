The nexus_base_ros package must contain 'include' dir.
